library(testthat)
test_check("spNetwork")
